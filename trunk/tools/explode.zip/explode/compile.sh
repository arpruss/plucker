gcc-3 -mno-cygwin -O99  -I libs/libjpeg -I libs/zlib-1.2.3 -o explode explode.c ../unpluck/unpluck.c ../unpluck/util.c ../unpluck/config.c -I ../unpluck/ libs/zlib-1.2.3/libz.a libs/libjpeg/libjpeg.a
