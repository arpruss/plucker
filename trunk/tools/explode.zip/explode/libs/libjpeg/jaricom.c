/*
 * jaricom.c
 *
 * [IJG Copyright notice]
 *
 * This file holds place for arithmetic entropy codec tables.
 */

#define JPEG_INTERNALS
#include "jinclude.h"
#include "jpeglib.h"

INT32 jaritab[1];	/* dummy table */
