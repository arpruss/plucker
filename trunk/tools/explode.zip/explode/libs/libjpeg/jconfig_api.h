/* jconfig_api.h.  Generated from jconfig_api.h.in by configure.  */
/* IJG JPEG Library Configuration Header  */

/* Characters are unsigned */
/* #undef CHAR_IS_UNSIGNED */

/* Compiler supports function prototypes. */
#define HAVE_PROTOTYPES 1

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Compiler supports 'unsigned char'. */
#define HAVE_UNSIGNED_CHAR 1

/* Compiler supports 'unsigned short'. */
#define HAVE_UNSIGNED_SHORT 1

/* Compiler does not support pointers to unspecified structures. */
/* #undef INCOMPLETE_TYPES_BROKEN */

/* Compiler has <strings.h> rather than standard <string.h>. */
/* #undef NEED_BSD_STRINGS */

/* Linker requires that global names be unique in first 15 characters. */
/* #undef NEED_SHORT_EXTERNAL_NAMES */

/* Need to include <sys/types.h> in order to obtain size_t. */
/* #undef NEED_SYS_TYPES_H */

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define 'void' as 'char' for archaic compilers that don't understand it. */
/* #undef void */
