Explode is GPL licensed software, (c) by the Plucker Development Team.
See COPYING for the license.

Compile by going to the explode directory and running compile.sh

To use explode from the command line, create an output directory, and do:
   explode --directory=outputdir pluckerfile.pdb

The home page will be in default.htm.  (I don't know what happens if your
home page is just an image.)

You can also specify --jpeg-quality=xxx (default is the maximum of 100).